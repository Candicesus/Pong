# A complex leveling Pong Game
# I started by setting up a window and setting it as a normal pong windoe screen.
#Credit to freeCodeCamp.Org for teaching me python and the code needed to be used, and goerge booles video titled "Python randomly chooses list elements"
import turtle
import random 
from replit import audio

sc = turtle.Screen()
sc.title("Fualty Pong")

#Setting the size of my window screen and color 
sc.setup(width=570, height=300)
sc.bgcolor("black")
sc.tracer(0)

#Paddle A
#Here I set up the shape of my 1st paddle as wekk as the clore and stretch it out to my desire
pad1 = turtle.Turtle()
pad1.shape("square")
pad1.color("white")
pad1.speed(0)
pad1.shapesize(stretch_wid=4, stretch_len=.5)
pad1.penup()
pad1.goto(-270, 0)

#Paddle B
#Here I set up the shape of my 2nd paddle as wekk as the clore and stretch it out to my desire and its location on screen.
pad2 = turtle.Turtle()
pad2.shape("square")
pad2.color("white")
pad2.speed(0)
pad2.shapesize(stretch_wid=4, stretch_len=.5)
pad2.penup()
pad2.goto(260, 0)

#Disc
#Here I set the speed of my pong as well as the shape and color 
disc = turtle.Turtle()
disc.speed(0)
disc.shape("circle")
disc.color("white")
disc.penup()
disc.goto(0, 0)
#The amount of pixels the ball will move  
disc.dx = .5
disc.dy = -.5

# Pen
#Here I set up the actual scoring mechanism so players can keep track of their score. 
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0,120)
pen.write("Player 1: 0  Player2: 0", align = "center", font = ("Comic Sans", 12, "bold"))

#Score
#In more of the hearty of Fualty pong a list mechanism that leaves the players score up to luck
#Here I used an example code by goerge booles
ranNum = [1,5,10]
s = random.choice(ranNum)
 
score1 = s
score2 = s
#Function
#I define how fast the paddle moves 
def pad1_over():
  y = pad1.ycor()
  y += 20
  pad1.sety(y)


def pad1_under():
  y = pad1.ycor()
  y -= 20
  pad1.sety(y)

  #Function 2 
def pad2_over():
  y = pad2.ycor()
  y += 20
  pad2.sety(y)
  
def pad2_under(): 
  y = pad2.ycor()
  y -= 20
  pad2.sety(y)

  #Event
  # On the event that the use presses a certain keybinding the paddle moves
def key_press():
  sc.listen()
  if sc.onkeypress(pad1_over, "a"):
    pad1_over()
  elif sc.onkeypress(pad1_under, "d"):
    pad1_under()

  #Event 2 
     # On the event that the use presses a certain keybinding the paddle moves
  sc.listen()
  if sc.onkeypress(pad2_over, "q"):
    pad2_over()
  elif sc.onkeypress(pad2_under, "e"):
    pad2_under()

#Main game loop
while True:
  key_press()
  sc.update()

  #Moves the ball
  disc.setx(disc.xcor()+disc.dx)
  disc.sety(disc.ycor()+disc.dy)

  #Border Checking
  #Makes sure the ball doesnt go off screen or out of bounds
  if disc.ycor() > 150:
    disc.sety(150)
    disc.dy *= -1
    sound = audio.play_file("cong.mp3")

  if disc.ycor() < -125:
    disc.sety(-125)
    disc.dy *= -1
    sound = audio.play_file("cong.mp3")

  if disc.xcor() > 350:
    disc.goto(0, 0)
    disc.dx *= -1
    score1 += 1
    
    
    pen.clear()
    pen.write("Player 1: {}  Player2: {}".format(score1, score2), align = "center", font = ("Comic Sans", 12, "bold"))

  #Here is where the score changes based off of who makes the goal
  if disc.xcor() < -350:
    disc.goto(0, 0)
    disc.dx *= -1
    score2 += 1
    pen.clear()
    pen.write("Player 1: {}  Player2: {}".format(score1, score2), align = "center", font = ("Comic Sans", 12, "bold"))

  #Paddle and Ball Collisions
    #Makes sure the disc bounces off the paddles and adds sound effects to ball actually bouncing
  if (disc.xcor() > 250 and disc.xcor() < 260) and     (disc.ycor() < pad2.ycor() + 50 and disc.ycor() > pad2.ycor() -40):
     disc.setx(250)
     disc.dx *= -1 
     sound = audio.play_file("movie_1.mp3")
  
  
  if (disc.xcor() < -240 and disc.xcor() > -245) and     (disc.ycor() < pad1.ycor() + 50 and disc.ycor() > pad1.ycor() -40):
     disc.setx(-240)
     disc.dx *= -1
     sound = audio.play_file("movie_1.mp3")